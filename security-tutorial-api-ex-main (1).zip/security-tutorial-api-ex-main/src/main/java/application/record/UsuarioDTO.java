package application.record;

public record UsuarioDTO (long id, String nomeDeUsuario, String senha) {
}
