package application.record;

public record GenericResponse(String message) {
    
}
