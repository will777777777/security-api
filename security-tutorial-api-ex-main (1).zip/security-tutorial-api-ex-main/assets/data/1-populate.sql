USE application;

INSERT INTO usuarios(nome_de_usuario, senha) VALUES
    ('admin', '$2a$12$ChE.DR.nQBHD4Vv99Q/3Du6/eAwvTmBQL70bxpXyL9FTyVcdvHCni');